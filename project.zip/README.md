# Kotan.pro static workspace

## Open in VS Code
1. Open VS Code.
2. File - Open Folder - select `site`.
3. When prompted, install recommended extensions.
4. Right-click `index.html` - Open with Live Server.

## Files you edit most
- `index.html`
- `css/main.css`
- `js/icons.js`
- SVGs in `assets/icons/`